package radool.levels;

import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;

import radool.server.RequestHandler;

public class Level2 implements RequestHandler {
	String flag = "REDACTED";
	private String secret = "REDACTED";

	private static String computeHmac(String json, String secret) {
		String sha1 = null;
		try {
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update((secret + json).getBytes("UTF-8"));
			sha1 = byteToHex(crypt.digest(), 4);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return sha1;
	}

	private static String byteToHex(final byte[] hash, int count) {
		Formatter formatter = new Formatter();
		for (int ii = 0; ii < count; ii++) {
			formatter.format("%02x", hash[ii]);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}

	public String handleRequest(byte[] request, int size) {
		JsonObjectBuilder job;
		JsonReader jsonReader;
		JsonObject jsonRoot, acheivements;
		String result;
		String response = "";
		String expectedHmac;
		String actualHmac;
		int rc;

		try {
			result = new String(request);
			jsonReader = Json.createReader(new StringReader(result));
			jsonRoot = jsonReader.readObject();
			actualHmac = jsonRoot.getString("checksum");
			job = Json.createObjectBuilder();
			for (String key : jsonRoot.keySet()) {
				if (!key.equals("checksum")) {
					job.add(key, jsonRoot.get(key));
				}
			}
			JsonObject noChecksum = job.build();
			String noChecksumStr = noChecksum.toString();
			expectedHmac = computeHmac(noChecksumStr, secret);
			rc = expectedHmac.compareTo(actualHmac);
			if (rc != 0) {
				response = "BIG BIRD ERROR CODE " + rc;
			} else {
				acheivements = jsonRoot.getJsonObject("achievements");
				int count = 0;
				int total = acheivements.size();
				for (String key : acheivements.keySet()) {
					int val = acheivements.getInt(key);
					if (val != 0) {
						count += val;
					}
				}
				if (count != total) {
					response = "ACHIEVEMENT PROGRESS: " + count + "/" + total;
					String state;
					for (String key : acheivements.keySet()) {
						state = acheivements.getInt(key) == 0 ? "NO" : "YES";
						response += "\n" + key + ": " + state;
					}
				} else {
					response = flag;
				}
			}
		} catch (Exception e) {
			response = "BIG BIRD IS UNHAPPY.";
			e.printStackTrace();
		}
		return response;
	}
}
