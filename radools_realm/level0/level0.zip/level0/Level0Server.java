package radool.levels;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import radool.server.RequestHandler;

public class Level0 implements RequestHandler {
	public String handleRequest(byte[] request, int size) {
		JsonReader jsonReader;
		JsonObject jsonRoot, achvs;
		String result;
		String response = "";
		String flag = "REDACTED";

		try {
			result = new String(request);
			jsonReader = Json.createReader(new StringReader(result));
			jsonRoot = jsonReader.readObject();
			achvs = jsonRoot.getJsonObject("achievements");
			int count = 0;
			int total = achvs.size();
			for (String key : achvs.keySet()) {
				int val = achvs.getInt(key);
				if (val != 0) {
					count += val;
				}
			}
			if (count != total) {
				response = "ACHIEVEMENT PROGRESS: " + count + "/" + total;
				String state;
				for (String key : achvs.keySet()) {
					state = achvs.getInt(key) == 0 ? "NO" : "YES";
					response += "\n" + key + ": " + state;
				}
			} else {
				response = flag;
			}

		} catch (Exception e) {
			response = "BIG BIRD IS UNHAPPY.";
			e.printStackTrace();
		}

		return response;
	}
}
